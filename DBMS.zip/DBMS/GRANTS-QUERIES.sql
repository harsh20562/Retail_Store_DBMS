use logintest;

grant select on product to 'cust1'@'localhost';
grant update on product to 'cust1'@'localhost';

grant select on authentication_system to 'cust1'@'localhost';
grant insert on authentication_system to 'cust1'@'localhost';

grant insert , select on user to 'cust1'@'localhost';

grant insert,select on Customer to 'cust1'@'localhost';

grant select on batch to 'cust1'@'localhost';

grant insert,select , update on Cart to 'cust1'@'localhost';

grant insert,select , update  on added_to to 'cust1'@'localhost';

grant insert,select , update  on orders to 'cust1'@'localhost';

grant select on coupons to 'cust1'@'localhost';

grant insert,select   on payment to 'cust1'@'localhost';

grant insert,select   on receipt to 'cust1'@'localhost';

grant insert,select , update   on vwpab to 'cust1'@'localhost';

grant insert,select , update   on vwatp to 'cust1'@'localhost';

grant insert,select , update   on vwreceipt to 'cust1'@'localhost';


show grants for 'cust1'@'localhost';


grant insert , select on authentication_system to 'emp1'@'localhost';

grant insert , select on user to 'emp1'@'localhost';

grant insert , select , update on Customer to 'emp1'@'localhost';

grant insert , select on employee to 'emp1'@'localhost';

grant insert , select , update , delete on product to 'emp1'@'localhost';

grant insert , select , update , delete on batch to 'emp1'@'localhost';

grant  select  on cart to 'emp1'@'localhost';

grant  select  on added_to to 'emp1'@'localhost';

grant  select  on orders to 'emp1'@'localhost';

grant insert , select , update , delete on coupons to 'emp1'@'localhost';

grant  select  on payment to 'emp1'@'localhost';

grant  select  on receipt to 'emp1'@'localhost';

grant insert , select , update , delete on stock_order to 'emp1'@'localhost';

grant insert , select , update , delete on supplier to 'emp1'@'localhost';

grant insert , select , update , delete on supplies to 'emp1'@'localhost';

grant insert , select , update , delete on vwpab to 'emp1'@'localhost';

grant insert , select , update , delete on vwatp to 'emp1'@'localhost';

GRANT EXECUTE ON *.* TO 'emp1'@'localhost';



show grants for 'emp1'@'localhost';


grant insert , select  on authentication_system to 'tempu'@'localhost';
grant insert , select  on user to 'tempu'@'localhost';
grant insert , select  on Customer to 'tempu'@'localhost';
grant insert , Select  , update on Cart to 'tempu'@'localhost';


show grants for 'tempu'@'localhost';





