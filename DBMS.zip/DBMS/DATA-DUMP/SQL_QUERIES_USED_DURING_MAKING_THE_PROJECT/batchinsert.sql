insert into Batch(Batch_ID , DOM , DOE ) values('B000007' , '2022-04-10' , '2022-06-22');
insert into Batch(Batch_ID , DOM , DOE ) values('B000008' , '2022-04-15' , '2022-06-22');
insert into Batch(Batch_ID , DOM , DOE ) values('B000009' , '2022-04-16' , '2022-06-22');
insert into Batch(Batch_ID , DOM , DOE ) values('B000010' , '2022-04-17' , '2022-06-22');
insert into Batch(Batch_ID , DOM , DOE ) values('B000011' , '2022-04-17' , '2022-06-22');
insert into Batch(Batch_ID , DOM , DOE ) values('B000012' , '2022-04-17' , '2022-06-22');





insert into Batch(Batch_ID , DOM , DOE ) values('B000013' , '2022-04-17' , '2022-07-22');
insert into Batch(Batch_ID , DOM , DOE ) values('B000014' , '2022-04-17' , '2022-07-22');
insert into Batch(Batch_ID , DOM , DOE ) values('B000015' , '2022-04-18' , '2022-07-22');
insert into Batch(Batch_ID , DOM , DOE ) values('B000016' , '2022-04-18' , '2022-07-22');
insert into Batch(Batch_ID , DOM , DOE ) values('B000017' , '2022-04-18' , '2022-07-22');
insert into Batch(Batch_ID , DOM , DOE ) values('B000018' , '2022-04-18' , '2022-07-22');



insert into Batch(Batch_ID , DOM , DOE ) values('B000019' , '2022-04-17' , '2022-09-22');
insert into Batch(Batch_ID , DOM , DOE ) values('B000020' , '2022-04-17' , '2022-09-22');
insert into Batch(Batch_ID , DOM , DOE ) values('B000021' , '2022-04-18' , '2022-09-22');


insert into Batch(Batch_ID , DOM , DOE ) values('B000023' , '2022-04-18' , '2022-09-22');
insert into Batch(Batch_ID , DOM , DOE ) values('B000025' , '2022-04-18' , '2022-09-22');
insert into Batch(Batch_ID , DOM , DOE ) values('B000028' , '2022-04-18' , '2022-09-22');
insert into Batch(Batch_ID , DOM , DOE ) values('B000029' , '2022-04-17' , '2022-09-22');
insert into Batch(Batch_ID , DOM , DOE ) values('B000030' , '2022-04-17' , '2022-09-22');
insert into Batch(Batch_ID , DOM , DOE ) values('B000031' , '2022-04-18' , '2022-09-22');
insert into Batch(Batch_ID , DOM , DOE ) values('B000032' , '2022-04-18' , '2022-09-22');
insert into Batch(Batch_ID , DOM , DOE ) values('B000033' , '2022-04-18' , '2022-09-22');
insert into Batch(Batch_ID , DOM , DOE ) values('B000034' , '2022-04-18' , '2022-09-22');

insert into Batch(Batch_ID , DOM , DOE ) values('B000035' , '2022-04-17' , '2022-09-01');
insert into Batch(Batch_ID , DOM , DOE ) values('B000036' , '2022-04-18' , '2022-09-01');
insert into Batch(Batch_ID , DOM , DOE ) values('B000037' , '2022-04-18' , '2022-09-01');
insert into Batch(Batch_ID , DOM , DOE ) values('B000038' , '2022-04-18' , '2022-09-01');

insert into Batch(Batch_ID , DOM , DOE ) values('B000039' , '2022-04-17' , '2022-07-22');
insert into Batch(Batch_ID , DOM , DOE ) values('B000040' , '2022-04-18' , '2022-07-22');
insert into Batch(Batch_ID , DOM , DOE ) values('B000041' , '2022-04-18' , '2022-07-22');
insert into Batch(Batch_ID , DOM , DOE ) values('B000042' , '2022-04-18' , '2022-07-22');
insert into Batch(Batch_ID , DOM , DOE ) values('B000043' , '2022-04-18' , '2022-07-22');
insert into Batch(Batch_ID , DOM , DOE ) values('B000044' , '2022-04-17' , '2022-07-22');
insert into Batch(Batch_ID , DOM , DOE ) values('B000045' , '2022-04-18' , '2022-07-22');
insert into Batch(Batch_ID , DOM , DOE ) values('B000046' , '2022-04-18' , '2022-07-22');
insert into Batch(Batch_ID , DOM , DOE ) values('B000047' , '2022-04-18' , '2022-07-22');
insert into Batch(Batch_ID , DOM , DOE ) values('B000048' , '2022-04-18' , '2022-07-22');

insert into Batch(Batch_ID , DOM ) values('B000050' , '2022-04-17' );
insert into Batch(Batch_ID , DOM ) values('B000051' , '2022-04-18' );
insert into Batch(Batch_ID , DOM ) values('B000052' , '2022-04-18' );
insert into Batch(Batch_ID , DOM ) values('B000053' , '2022-04-18' );
insert into Batch(Batch_ID , DOM ) values('B000054' , '2022-04-18' );
insert into Batch(Batch_ID , DOM ) values('B000055' , '2022-04-17' );
insert into Batch(Batch_ID , DOM ) values('B000056' , '2022-04-18' );
insert into Batch(Batch_ID , DOM ) values('B000057' , '2022-04-18' );
insert into Batch(Batch_ID , DOM ) values('B000058' , '2022-04-18' );
insert into Batch(Batch_ID , DOM ) values('B000059' , '2022-04-18' );
insert into Batch(Batch_ID , DOM ) values('B000060' , '2022-04-17' );
insert into Batch(Batch_ID , DOM ) values('B000061' , '2022-04-18' );
insert into Batch(Batch_ID , DOM ) values('B000062' , '2022-04-18' );
insert into Batch(Batch_ID , DOM ) values('B000063' , '2022-04-18' );
insert into Batch(Batch_ID , DOM ) values('B000064' , '2022-04-18' );

insert into Batch(Batch_ID , DOM , DOE ) values('B000001' , '2022-04-17' , '2022-05-01');
insert into Batch(Batch_ID , DOM , DOE ) values('B000002' , '2022-04-18' , '2022-05-01');
insert into Batch(Batch_ID , DOM , DOE ) values('B000003' , '2022-04-19' , '2022-05-01');
insert into Batch(Batch_ID , DOM , DOE ) values('B000004' , '2022-04-27' , '2022-05-01');
insert into Batch(Batch_ID , DOM , DOE ) values('B000005' , '2022-04-20' , '2022-05-01');
insert into Batch(Batch_ID , DOM , DOE ) values('B000006' , '2022-04-21' , '2022-05-01');

insert into Batch(Batch_ID , DOM , DOE ) values('B000026' , '2022-04-18' , '2022-05-22');
insert into Batch(Batch_ID , DOM , DOE ) values('B000022' , '2022-04-18' , '2022-05-22');
insert into Batch(Batch_ID , DOM , DOE ) values('B000024' , '2022-04-18' , '2022-05-22');

insert into Batch(Batch_ID , DOM , DOE ) values('B000027' , '2022-04-18' , '2022-05-22');
insert into Batch(Batch_ID , DOM , DOE ) values('B000049' , '2022-04-18' , '2022-05-22');

select * from batch;